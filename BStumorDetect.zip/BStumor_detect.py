# BStumor_detect.py  2021/9/5 neoCaffe
import numpy as np 
import pandas as pd 
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

''' Step 1. 以dataframe 讀取csv '''
print('以dataframe 讀取 csv')
df = pd.read_csv('BStumorKaggle.csv')
print(f'df.shape : {df.shape}')
print(f'欄位: {df.columns}')
print(f'前5筆記錄: {df.head()}')
# 節省篇幅，也因為欄位內容都沒有缺損，所以這裡沒有寫nan之處理

''' Step 2. 資料前處理 '''
# 設定 X ,y 
y = df['diagnosis']    # y 診斷結果=diagnosis 欄位
''' 去除 id diagnosis 兩個分類欄位，剩下特徵欄位-->X '''
df2 = df.drop(['id', 'diagnosis'], axis = 1)
print(df2.shape)
X = df2
print(X.head())   # X is a dataframe
print(y[:5])      # y is a Series

''' Step 3. Split data 分成 training 、testing 兩組 '''
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 42)

''' Step 4. Build the Model : training'''
# model logistic regression
from sklearn.linear_model import LogisticRegression
logis = LogisticRegression(solver='lbfgs',max_iter=400)
logis.fit(X_train, y_train)

# model random forest
from sklearn.ensemble import RandomForestClassifier
fores = RandomForestClassifier()
fores.fit(X_train, y_train)

''' 測試 抓一筆資料，試試看。此筆資料的 diagnosis 是 M '''
newX =[[13.73,22.61,93.6,578.3,0.1131,0.2293,0.2128,0.08025,
        0.2069,0.07682,0.2121,1.169,2.061,19.21,0.006429,0.05936,
        0.05501,0.01628,0.01961,0.008093,15.03,32.01,108.8,697.7,
        0.1651,0.7725,0.6943,0.2208,0.3596,0.1431]]

newP_logis = logis.predict(newX)  # 預測值
newP_fores = fores.predict(newX)
print(f'真正的診斷: M   LogisticRegression 預測診斷: {newP_logis}')
print(f'真正的診斷: M   RandomForest 預測診斷: {newP_fores}')

''' Step 5. 評估模型準確度  兩種model的accuracy '''
from sklearn.metrics import accuracy_score
pred_logis = logis.predict(X_test)
pred_fores = fores.predict(X_test)

a1 = accuracy_score(pred_logis, y_test)
a2 = accuracy_score(pred_fores, y_test)
print(f'兩種模型的準確率 accuracy: logis: {a1}  fores: {a2}')

''' Step 6. 儲存模型  '''
import pickle

mdl_BSlr = 'BSlr.model'
pickle.dump(logis, open(mdl_BSlr, 'wb'))
mdl_BSfs = 'BSfs.model'
pickle.dump(fores, open(mdl_BSfs, 'wb'))
print('models saved ')
# --- 建模完成 ---
