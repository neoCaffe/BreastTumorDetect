""" 
    使用建立好的模型，進行診斷預測 Breast tumor
    取兩筆資料的特徵欄位，從BStumorKaggle.csv取兩筆
    test1  id 85491   diagnosis B
    test2  id 855133  diagnosis M
"""
print(__doc__)

import pickle
test1 =[[13.03,18.42,82.61,523.8,0.08983,0.03766,0.02562,0.02923,
         0.1467,0.05863,0.1839,2.342,1.17,14.16,0.004352,0.004899,
         0.01343,0.01164,0.02671,0.001777,13.3,22.81,84.46,545.9,
         0.09701,0.04619,0.04833,0.05013,0.1987,0.06169]]
test2 =[[14.99,25.2,95.54,698.8,0.09387,0.05131,0.02398,0.02899,
         0.1565,0.05504,1.214,2.188,8.077,106,0.006883,0.01094,
         0.01818,0.01917,0.007882,0.001754,14.99,25.2,95.54,698.8,
         0.09387,0.05131,0.02398,0.02899,0.1565,0.05504]]

''' 以兩種模型進行預測 predict with loaded model '''
mdl_logis = pickle.load(open('BSlr.model', 'rb'))
predict1 = mdl_logis.predict(test1)

mdl_fores = pickle.load(open('BSfs.model', 'rb'))
predict2 = mdl_fores.predict(test2)

print(f'test1 真正診斷是: B  以logis模型預測是: {predict1}')
print(f'test2 真正診斷是: M  以fores模型預測是: {predict2}')
